Instrucciones de Implementación

Bienvenidos al reto AutoText, para cumplirlo deberán seguir lo siguiente:

1. Ver el video de explicación de reto.

2. Tienen los siguientes recursos: Entregamos el HTML con las clases correspondientes, css básico y js con la estructura que deben seguir*
   
   * En este caso les damos una estructura guía donde deben encontrar las variables e identificadores necesarios en cada caso.

3. Deberán completar el css y el js para que el reto funcione.

Resultado: El reto debe ser igual al que visualizan en el video (pueden cambiar colores e imagenes), deben crear un buen .body para que sea como el del video.


¡HINTS!

CSS

 - El body cambia con los @media queries -


JS

 - Validar paso a paso hacer uso de console.log() y la herramienta de desarrollador - 

- Definir la velocidad

- utilizar los métodos js para defirnir el lenght

- setTimeOut recibe 2 parametros

- addEventListner ('', () => xxxx = 300, x.xxxxxx.xxxxx)