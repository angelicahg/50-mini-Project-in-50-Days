const textEl = document.getElementById('')
let idx = 1
let speed =  / speedEl.value

writeText()

funtion writeText{
    textEl.innerText =

    idx++

    if(idx > text.) {
        idx = 1
    }

    setTimeout()
}


speedEl.addEventListener('', (e) => speed =  / )